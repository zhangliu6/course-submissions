zlx.plus <- function(A,B){
  #coerce inputs into matrices
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1] #the same as ma <- nrow(A)
  na <- dim(A)[2] #the same as na <- ncol(A)
  mb <- dim(B)[1] 
  nb <- dim(B)[2]
  #if dimensions do not match, then addition is invalid. Hence, output error message. 
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(ma != mb | na != nb)
    print("ERROR: the dimensions do not match.")
  else{
    #if the dimensions match, then add the two matrices. 
    #first, intialize the result matrix
    C = matrix(data = 0, nrow = ma, ncol = na, byrow = TRUE)
    for(i in 1:ma){
      for(j in 1:na){
        C[i,j] <- A[i,j] + B[i,j] 
      }
    }
    return(C)
  }
}

# Scaling of a matrix A by a scalar a
# flop count = O(mn)
zlx.scale <- function(A, a){
  if(!is.numeric(A))
    print("ERROR: entries in the input matrix is not numeric.")
  else{
    A <- as.matrix(A)
    ma <- dim(A)[1]
    na <- dim(A)[2]
    for(i in 1:ma){
      for(j in 1:na){
        A[i,j] <- A[i,j] * a
      }
    }
    return(A)
  }
} 

# Dot product of two vectors, v and u
# flop count = O(n)
zlx.dot <- function(A, B){
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1] 
  na <- dim(A)[2]
  mb <- dim(B)[1] 
  nb <- dim(B)[2]
  #check that row(v)=column(u)
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(na > 1 | nb > 1)
    print("ERROR: not a vector.")
  else if(ma != mb)
    print("ERROR: the dimensions do not match.")
  else{
    ans <- 0
    i <- 1  
    while(i <= ma){
      ans <- ans + A[i]*B[i]
      i <- i + 1
    }
    return(ans)
  }
}

# Multiplication of matrices, A and B
# flop count = O(ma*na*nb), asymptotically O(n^3)
zlx.times <- function(A, B){
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1]
  na <- dim(A)[2]
  mb <- dim(B)[1]
  nb <- dim(B)[2]
  #check that na = mb
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(na != mb)
    print("ERROR: the dimensions do not match.")
  else{
    #initialize result matrix to all zeros
    C = matrix(data = 0, nrow = ma, ncol = nb, byrow = TRUE)
    for(i in 1:ma){
      for(j in 1:nb){
        k <- 1
        while(k <= na){
          C[i,j] <- C[i,j] + A[i,k] * B[k,j]
          k <- k + 1
        }
      }
    }
    return(C)
  }
}

## Gaussian_elimination, which will be useful for finding inverse and determinant

Gaussian_elimination <- function(aug_A){
  n <- nrow(aug_A)
  column <- ncol(aug_A)
  ##  is to detect the no of columns in the aug_A input
  ## this is to make the function more general 
  ## (able to take matrices of different shapes without going out of bounds)
  flag <- FALSE
  for(j in 1 : (n-1)){
    ## pivoting
    if(aug_A[j,j] == 0){
      flag <- TRUE
      for(k in (j+1) : n){
        if(aug_A[k,j] != 0){
          flag <- FALSE
          ## switch rows k and j 
          temp <- aug_A[k, 1:column]
          aug_A[k, 1:column] <- aug_A[j, 1:column]
          aug_A[j, 1:column] <- temp
          break
        } 
      }
    }
    ## if there is row to exchange -> singular
    if(flag)break
    
    ## elimination
    for(i in (j+1) : n){
      m <- aug_A[i,j] / aug_A[j,j]
      for(k in j : column){
        aug_A[i, k] <- aug_A[i, k] - m * aug_A[j, k]
      }
    }
  }
  if(aug_A[n,n] == 0)flag = TRUE
  
  if(flag)return(-1)
  else return(aug_A)
}

## Finding the inverse of a square matrix A, using Gauss-Jordan Method
zlx.inverse <- function(A){
  if(!is.numeric(A))
    return("ERROR: entries in the input matrix are not numeric!")
  else{
    A <- as.matrix(A)
    ## construct augmented matrix
    n <- nrow(A)
    n <- nrow(A)
    #if(n != ncol(A))return("ERROR: matrix is not square!")
    
    I <- diag(n)
    aug_A <- matrix(0, nrow = n, ncol= n*2)
    aug_A[1 : n, 1 : n] <- A
    aug_A[1 : n, (n+1) : (n*2)] <- I
    
    ## reduce to upper-triangular matrix
    aug_U <- Gaussian_elimination(aug_A)
    
    ## if the matrix is not invertible
    if(length(aug_U) == 1 && aug_U == -1)return("ERROR: A is not invertible!")
    
    ## reduce U|C to I|C
    for(i in 1 : n){
      ## scale each row such that the pivot becomes 1
      alpha <- 1 / aug_U[i,i]
      aug_U[i,i] <- 1 
      aug_U[i, (i+1) : (n*2)] <- aug_U[i, (i+1) : (n*2)] * alpha 
    }
    for(j in n : 2){
      for(i in (j-1) : 1){
        for(k in (n+1) : (n*2)){
          aug_U[i, k] <- aug_U[i, k] - aug_U[j, k] * aug_U[i, j]
          ## DEBUG NOTE: this should NOT be aug_U[i, k] - aug_U[i, k] * aug_U[i, j]
          ## We are minusing off some multiple of the jth row from the ith row. 
        }
        aug_U[i,j] <- 0
      }
    }
    A_inv <- aug_U[1 : n, (n+1) : (n*2)]
    return(A_inv)
  }
}

## QR Factorization

zlx.QR <- function(A){
  if(!is.numeric(A))
    return("ERROR: entries in the input matrix are not numeric!")
  else{
    A <- as.matrix(A)
    n <- nrow(A)
    m <- ncol(A)
    
    ## check square matrix
    if(n!=m)return("ERROR: matrix is not square!")
    
    ## check singualr matrix 
    
    if(length(Gaussian_elimination(A)) == 1 && Gaussian_elimination(A) == -1)
      return("ERROR: matrix is singular!")
    
    R <- matrix(0,m,m)
    Q <- matrix(0,n,m)
    
    for(j in 1:m){
      v <- A[,j]
      if(j >= 2){
        for(i in 1:(j-1)){
          
          R[i,j] <- zlx.dot(Q[,i], A[,j])
          
          v <- zlx.plus(v,zlx.scale(zlx.scale(Q[,i], R[i,j]),-1))
          
          #v <- v-R[i,j]*Q[,i] involves built-in vectorization
        }
      }
      
      R[j,j] <- sqrt(sum(zlx.dot(v,v)))
      
      
      Q[,j] <- zlx.scale(v, 1/R[j,j])
      
      #Q[,j] <- v/R[j,j] involves built-in vectorization
    }
    return(list(Q,R))
  }
}

## 1. QR Algorithm to compute the eigenvalues and eigenvectors of an nxn symmetric matrix.
zlx.eig <- function(A){ 
  if(!is.numeric(A))
    return("ERROR: entries in the input matrix are not numeric!")
  
  A <- as.matrix(A)
  ## Check A is a sqaure, symmetric matrix
  n <- nrow(A)
  if(n != ncol(A))return("ERROR: matrix is not square!")
  
  # can we use this?
  if(!isSymmetric.matrix(A))return("ERROR: matrix is not symmetric!") 
  
  An <- A
  Qn <- diag(n)
  
  ## 100 iterations should be enough
  for(i in 1:1000){
    
    Q <- zlx.QR(An)[[1]] 
    R <- zlx.QR(An)[[2]] 
    
    An <- zlx.times(R,Q) 
    
    Qn <- zlx.times(Qn,Q)
    
  }
  
  eig <- rep(0,n)
  
  for(i in 1:n){
    eig[i] <- An[i,i]
  }
  
  ## return a square matrix of eigenvectors and a list of eigenvalues
  return(list(Qn,eig))
}

## 2. SVD of an mxn matrix.
zlx.svd <- function(A){
  return(U,S,V)
}

## 3. Construct the pseudo-inverse of an mxn matrix. 
zlx.pseudo <- function(A){
  return()
}