

## flop count: 
## zlx.utsolve(): O(n^2)
## zlx.solve(): O(2/3n^3), asmptotically O(n^3)
## zlx.LU(): O(n^3)
## zlx.PALDU(): O(n^3)
## where n is the dimension of square matrix

### Coding Assignment 2 ###

# Scaling of a matrix A by a scalar a
zlx.scale <- function(A, a){
  if(!is.numeric(A))
    print("ERROR: entries in the input matrix is not numeric.")
  else{
    A <- as.matrix(A)
    ma <- dim(A)[1]
    na <- dim(A)[2]
    for(i in 1:ma){
      for(j in 1:na){
        A[i,j] <- A[i,j] * a
      }
    }
    return(A)
  }
} 

# Multiplication of matrices, A and B
zlx.times <- function(A, B){
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1]
  na <- dim(A)[2]
  mb <- dim(B)[1]
  nb <- dim(B)[2]
  #check that na = mb
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(na != mb)
    print("ERROR: the dimensions do not match.")
  else{
    #initialize result matrix to all zeros
    C = matrix(data = 0, nrow = ma, ncol = nb, byrow = TRUE)
    for(i in 1:ma){
      for(j in 1:nb){
        k <- 1
        while(k <= na){
          C[i,j] <- C[i,j] + A[i,k] * B[k,j]
          k <- k + 1
        }
      }
    }
    return(C)
  }
}

# 1. Solving an nxn upper triangular system of linear equations. 

zlx.utsolve <- function(U, b){
  # inputs an n*n square, upper-triangular matrix and a vector
  if(!is.numeric(U))
    print("ERROR: entries in the input matrix is not numeric.")
  else{
    U <- as.matrix(U)
    
    # not solvable case: zero pivot
    n <- nrow(U)
    flag <- TRUE
    for(i in 1:n){
      if(U[i,i] != 0){
        flag <- FALSE
        break
      }
    }
    if(flag){
      print("ERROR: the system is not solvable.")
    }
    else{
      if(ncol(U) == n){
        # create augmented matrix
        aug_U <- matrix(0, nrow = n,ncol= n+1)
        aug_U[1 : n, 1 : n] <- U
        aug_U[1 : n, n+1] <- b
      }
      else{
        aug_U <- U
      }
      # if the system is not solvable, print("Not solvable.")
      
      # create a vector
      x <- rep(0,n+1)
      
      for(i in n:1){
        x[i] <- b[i] 
        for(j in (i+1):n){
          if(i+1 <= n)x[i] <- x[i] - aug_U[i,j]*x[j] 
          ### DEBUG NOTE: the if-statement is important for edge case to prevent double countring 
          ### (we want to ensure the direction is always left to right, up to down)
        }
        x[i] <- x[i]/aug_U[i,i]
      }
      return(x[1:n])
    }
  }
}

# 2. Solving an arbitrary nxn system of linear equations.
zlx.solve <- function(A,b){
  
  if(!is.numeric(A))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(nrow(A) != ncol(A))
    print("ERROR: the matrix is not square.")
  else{
    A <- as.matrix(A)
    
    # not solvable case: zero pivot
    n <- nrow(A)
    flag <- TRUE
    for(i in 1:n){
      if(A[i,i] != 0){
        flag <- FALSE
        break
      }
    }
    if(flag){
      print("ERROR: the system is not solvable.")
    }
    else{
      # inputs a square matrix and a vector, and return a vector
      # if the system is not solvable, print("No solution.")
      # into the upper-traingular form
      
      aug_A <- matrix(0, nrow = n,ncol= n+1)
      aug_A[1 : n, 1 : n] <- A
      aug_A[1 : n, n + 1] <- b
      
      M <- matrix(0, nrow = n, ncol = n)
      
      
      for(k in 1:(n-1)){
        
        L <- diag(n)
        L_inv <- diag(n)
        decom_L <- diag(n)
        decom_U <- A
        
        for(i in (k+1):n){
          
          M[i,k] <- aug_A[i,k] / aug_A[k,k]
          
          for(j in (k+1):n){
            aug_A[i,j] <- aug_A[i,j] - M[i,k] * aug_A[k,j]
          }
          
          b[i] <- b[i] - M[i,k] * b[k]
        }
        
        L[(k+1):n,k] <- zlx.scale(M[(k+1):n,k],-1)
        
        L_inv[(k+1):n,k] <- M[(k+1):n,k]
        
        decom_L <- zlx.times(decom_L, L_inv)
        
        decom_U <- zlx.times(L, decom_U)
      }
      
      aug_A[1 : n, n+1] <- b
      x <- zlx.utsolve(aug_A,b)
      return(x)
    }
  }
}

#x <- zlx.solve(matrix(data = c(1,2,1,-1,3,2,4,4,4,4,3,4,2,0,1,5), nrow = 4, ncol = 4, byrow = TRUE), c(5,16,22,15))
# x <- zlx.solve(matrix(data = c(3,-4,-1,6,-3,-1,-3,4,3), nrow = 3, ncol = 3, byrow = TRUE), c(0,6,-4))
#print(x)



# 3. Compute the LU decomposition of a square matrix. 


zlx.LU <- function(A){
  
  if(!is.numeric(A))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(nrow(A) != ncol(A))
    print("ERROR: the matrix is not square.")
  else{
    A <- as.matrix(A)
    
    # not solvable case: zero pivot
    n <- nrow(A)
    flag <- TRUE
    for(i in 1:n){
      if(A[i,i] != 0){
        flag <- FALSE
        break
      }
    }
    if(flag){
      print("ERROR: the matrix is singular.")
    }
    else{
      # as inputs a square matrix
      # A = LU
      n <- nrow(A)
      
      aug_A <- matrix(0, nrow = n,ncol= n+1)
      aug_A[1 : n, 1 : n] <- A
      
      m <- matrix(0, nrow = n, ncol = n)
      
      decom_L <- diag(n)
      decom_U <- A
      
      for(k in 1:(n-1)){
        
        L <- diag(n)
        L_inv <- diag(n)
        
        for(i in (k+1):n){
          
          m[i,k] <- aug_A[i,k] / aug_A[k,k]
          
          for(j in (k+1):n){
            aug_A[i,j] <- aug_A[i,j] - m[i,k] * aug_A[k,j]
          }
        }
        
        L[(k+1):n,k] <- zlx.scale(m[(k+1):n,k],-1)
        
        L_inv[(k+1):n,k] <- m[(k+1):n,k]
        
        decom_L <- zlx.times(decom_L, L_inv)
        
        decom_U <- zlx.times(L, decom_U)
      }
      
      # return a list consisting of a square, lower-triangular matrix and a square, upper-triangular matrix.
      return(list(decom_L,decom_U))
    }
  }
}

# print(zlx.LU(matrix(data = c(1,2,1,-1,3,2,4,4,4,4,3,4,2,0,1,5), nrow = 4, ncol = 4, byrow = TRUE)))
# print(zlx.LU(matrix(data = c(3,2,4,4,0,2,1,-1,4,4,3,4,2,0,1,5), nrow = 4, ncol = 4, byrow = TRUE)))

# 4. Compute the PA = LDU decomposition of a square matrix. 
zlx.PALDU <- function(A){
  # as inputs a square matrix
  # A = LU
  n <- nrow(A)
  
  aug_A <- matrix(0, nrow = n,ncol= n+1)
  aug_A[1 : n, 1 : n] <- A
  
  m <- matrix(0, nrow = n, ncol = n)
  
  decom_L <- diag(n)
  decom_M <- A
  decom_P <- diag(n)
  
  for(k in 1:(n-1)){
    
    L <- diag(n)
    M <- diag(n)
    P <- diag(n)
    
    # if the current pivot position is zero, swap
    if(aug_A[k,k] == 0){
      flag <- TRUE
      for(t in (k+1):n){
        if(aug_A[t,k] != 0){
          flag <- FALSE
          temp <- aug_A[k,1:(n+1)] 
          
          aug_A[k,1:(n+1)] <- aug_A[t,1:(n+1)]
          aug_A[t,1:(n+1)] <- temp
          
          temp <- P[k,1:n] 
          P[k,1:n] <- P[t,1:n]
          P[t,1:n] <- temp
          
          temp <- decom_L[k,1:(k-1)] 
          decom_L[k,1:(k-1)] <- decom_L[t,1:(k-1)]
          decom_L[t,1:(k-1)] <- temp
          
          temp <- decom_M[k,1:n] 
          decom_M[k,1:n] <- decom_M[t,1:n]
          decom_M[t,1:n] <- temp
          
          break
        }
      }
      
      if(flag){
        print("ERROR: the matrix is singular.")
        break
      }
    }
    for(i in (k+1):n){
      
      m[i,k] <- aug_A[i,k] / aug_A[k,k]
      
      for(j in (k+1):n){
        aug_A[i,j] <- aug_A[i,j] - m[i,k] * aug_A[k,j]
      }
      
    }
    
    M[(k+1):n,k] <- zlx.scale(m[(k+1):n,k],-1)
    
    L[(k+1):n,k] <- m[(k+1):n,k]
    
    decom_L <- zlx.times(decom_L, L)
    
    decom_M <- zlx.times(M, decom_M)
    
    decom_P <- zlx.times(P, decom_P) 
  }
  
  # find D based on decom_M 
  
  decom_D <- matrix(0, nrow = n, ncol = n, byrow =  TRUE)
  for(i in 1:n){
    decom_D[i,i] <- 1 / decom_M[i,i]
  }
  inv_D <- matrix(0, nrow = n, ncol = n, byrow =  TRUE)
  for(i in 1:n){
    inv_D[i,n-i+1] <- decom_D[i,i]
  }

  decom_M <- zlx.times(inv_D,decom_M)
  #return a list consisting of a square permutation matrix, a square, lower-triangular matrix, a square diagonal matrix, and a square, upper-triangular matrix.
  #return(list(decom_P,decom_L, decom_D, decom_U))
  #print(zlx.times(decom_D, decom_M))
  return(list(decom_P,decom_L, decom_D, decom_M))
}

# print(zlx.PALDU(matrix(data = c(2,-3,4,3,6,-9,12,8,4,-5,6,7,2,1,-1,8), nrow = 4, ncol = 4, byrow = TRUE)))









