### flop count
## 1. zlx.inverse = Gaussian_elimination (asymptotically O(n^3)) + reduce U to I (asymptotically O(n^3)) = asymptotically O(n^3)

## 2. zlx.det = Gaussian_alimination (O(n^3)) + product of diagonal (O(n))= asymptotically O(n^3)
## the no. of addition = (1/3)n^3 + (1/2)n^2 - (5/6)n
## the no. of multiplication = (1/3)n^3 + n^2 + (1/3)n

## 3. zlx.codet = recusioin on the minor = O((n-1)n!)

## 4. zlx.cramer = (n+1) iterations of zlx.codet = O((n-1)(n+1)!) 

#### Compare runtime (worst-case):
## methodology: 
## system.time(zlx.*(matrix(data = c(runif(*, min = 0, max = 25)), nrow = *, ncol = *, byrow = TRUE)), gcFirst = TRUE)
## run the above code multiple times and find the worst runtime for each case 

## For 5 by 5 matrix: 
##   Gaussian Elimination: system.time(zlx.det) =  0.03
##   Cofactor expansion: system.time(zlx.codet) = 0.04
##   Gaussian Elimination: system.time(zlx.solve) = 0.04
##   Cramer's rule: system.time(zlx.cramer) = 0.04
##   On average the difference in speed is not very obvious, although cofactor seems to be slower in general. 

## For 6 by 6 matrix: 
##   Gaussian Elimination: system.time(zlx.det) =  0.02
##   Cofactor expansion: system.time(zlx.codet) = 0.03
##   Gaussian Elimination: system.time(zlx.solve) = 0.03
##   Cramer's rule: system.time(zlx.cramer) = 0.05
##   Using cofactor is notably slower than using Gaussian Elimination.

## Gaussian_elimination, which will be useful for finding inverse and determinant

Gaussian_elimination <- function(aug_A){
  n <- nrow(aug_A)
  column <- ncol(aug_A)
  ##  is to detect the no of columns in the aug_A input
  ## this is to make the function more general 
  ## (able to take matrices of different shapes without going out of bounds)
  flag <- FALSE
  for(j in 1 : (n-1)){
    ## pivoting
    if(aug_A[j,j] == 0){
      flag <- TRUE
      for(k in (j+1) : n){
        if(aug_A[k,j] != 0){
          flag <- FALSE
          ## switch rows k and j 
          temp <- aug_A[k, 1:column]
          aug_A[k, 1:column] <- aug_A[j, 1:column]
          aug_A[j, 1:column] <- temp
          break
        } 
      }
    }
    ## if there is row to exchange -> singular
    if(flag)break
    
    ## elimination
    for(i in (j+1) : n){
      m <- aug_A[i,j] / aug_A[j,j]
      for(k in j : column){
        aug_A[i, k] <- aug_A[i, k] - m * aug_A[j, k]
      }
    }
  }
  if(aug_A[n,n] == 0)flag = TRUE
  
  if(flag)return(-1)
  else return(aug_A)
}

## 1. Finding the inverse of a square matrix A, using Gauss-Jordan Method

## Gauss-Jordan Method
zlx.inverse <- function(A){
  if(!is.numeric(A))
    return("ERROR: entries in the input matrix are not numeric!")
  else{
    A <- as.matrix(A)
    ## construct augmented matrix
    n <- nrow(A)
    n <- nrow(A)
    if(n != ncol(A))return("ERROR: matrix is not square!")
    
    I <- diag(n)
    aug_A <- matrix(0, nrow = n, ncol= n*2)
    aug_A[1 : n, 1 : n] <- A
    aug_A[1 : n, (n+1) : (n*2)] <- I
    
    ## reduce to upper-triangular matrix
    aug_U <- Gaussian_elimination(aug_A)
    
    ## if the matrix is not invertible
    if(length(aug_U) == 1 && aug_U == -1)return("ERROR: A is not invertible!")
    
    ## reduce U|C to I|C
    for(i in 1 : n){
      ## scale each row such that the pivot becomes 1
      alpha <- 1 / aug_U[i,i]
      aug_U[i,i] <- 1 
      aug_U[i, (i+1) : (n*2)] <- aug_U[i, (i+1) : (n*2)] * alpha 
    }
    for(j in n : 2){
      for(i in (j-1) : 1){
        for(k in (n+1) : (n*2)){
          aug_U[i, k] <- aug_U[i, k] - aug_U[j, k] * aug_U[i, j]
          ## DEBUG NOTE: this should NOT be aug_U[i, k] - aug_U[i, k] * aug_U[i, j]
          ## We are minusing off some multiple of the jth row from the ith row. 
        }
        aug_U[i,j] <- 0
      }
    }
    A_inv <- aug_U[1 : n, (n+1) : (n*2)]
    return(A_inv)
  }
}

## 2. Compute the determinant of an nxn matrix using Gaussian elimination

zlx.det <- function(A){
  if(!is.numeric(A))
    return("ERROR: entries in the input matrix are not numeric!")
  else{
    A <- as.matrix(A)
    n <- nrow(A)
    if(n != ncol(A))return("ERROR: matrix is not square!")
    ## reduce to upper-triangular matrix
    U <- Gaussian_elimination(A)

    if(length(U) == 1 && U == -1)return(0)
    else{
      det <- 1
      for(i in 1:n){
        det <- det * U[i,i]
      }
      return(det)
    }
  }
}

## 3. Compute the determinant of an nxn matrix using co-factor expansion

zlx.codet <- function(A){
  if(!is.numeric(A))
    return("ERROR: entries in the input matrix are not numeric!")
  else{
    A <- as.matrix(A)
    n = nrow(A)
    if(n != ncol(A))return("ERROR: matrix is not square!")
    
    if(n == 2)return(A[1,1]*A[2,2]-A[1,2]*A[2,1])
    else{
      ## check boundary case: the following also works there is no zero at all
      max <- -1
      for(i in 1:n){
        n_zero <- 0
        for(j in 1:n){
          if(A[i,j] == 0)n_zero <- n_zero + 1
        }
        if(n_zero > max){
          max <- n_zero
          good_row <- i
        }
      }
      
      ## Laplace expansion on a good row, one that has the most zeros
      det <- 0
      for(j in 1:n){
        ## recursion on the minor
        minor_A <- A[-good_row, -j] 
        
        cofactor <- (-1)^(good_row + j) * zlx.codet(minor_A)
        
        det <- det + A[good_row, j] * cofactor
      }
      return(det)
    }
  }
}

## 4. Solve an nxn system of linear equations using Cramer's rule.

zlx.cramer <- function(A,b){
  if(!is.numeric(A))
    return("ERROR: entries in the input are not numeric.")
  else{
    A <- as.matrix(A)
    n <- nrow(A)
    if(n != ncol(A))return("ERROR: the system is not n by n!")
    
    det_A <- zlx.codet(A)
    
    ## error handling: if the system is not solvable
    if(det_A == 0)return("ERROR: the system is not solvable!")
    
    # create a vector to store solutions
    x <- rep(0,n)
    for(j in 1:n){
      B <- A 
      B[,j] <- b
      det_Bj <- zlx.codet(B)
      x[j] <- det_Bj/det_A
    }
    return(x)
  }
}
