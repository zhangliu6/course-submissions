# Coding Assignment 1: Addition, scalar multiplication, dot product, matrix multiplication.

# 1. Addition of two matrices, A and B
# flpp count = O(mn)
zlx.plus <- function(A,B){
  #coerce inputs into matrices
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1] #the same as ma <- nrow(A)
  na <- dim(A)[2] #the same as na <- ncol(A)
  mb <- dim(B)[1] 
  nb <- dim(B)[2]
  #if dimensions do not match, then addition is invalid. Hence, output error message. 
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(ma != mb | na != nb)
    print("ERROR: the dimensions do not match.")
  else{
    #if the dimensions match, then add the two matrices. 
    #first, intialize the result matrix
    C = matrix(data = 0, nrow = ma, ncol = na, byrow = TRUE)
    for(i in 1:ma){
      for(j in 1:na){
        C[i,j] <- A[i,j] + B[i,j] 
      }
    }
    return(C)
  }
}

# 2. Scaling of a matrix A by a scalar a
# flop count = O(mn)
zlx.scale <- function(A, a){
  if(!is.numeric(A))
    print("ERROR: entries in the input matrix is not numeric.")
  else{
    A <- as.matrix(A)
    ma <- dim(A)[1]
    na <- dim(A)[2]
    for(i in 1:ma){
      for(j in 1:na){
        A[i,j] <- A[i,j] * a
      }
    }
    return(A)
  }
} 

# 3. Dot product of two vectors, v and u
# flop count = O(n)
zlx.dot <- function(A, B){
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1] 
  na <- dim(A)[2]
  mb <- dim(B)[1] 
  nb <- dim(B)[2]
  #check that row(v)=column(u)
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(na > 1 | nb > 1)
    print("ERROR: not a vector.")
  else if(ma != mb)
    print("ERROR: the dimensions do not match.")
  else{
    ans <- 0
    i <- 1  
    while(i <= ma){
      ans <- ans + A[i]*B[i]
      i <- i + 1
    }
    return(ans)
  }
}

# 4. Multiplication of matrices, A and B
# flop count = O(ma*na*nb), asymptotically O(n^3)
zlx.times <- function(A, B){
  A <- as.matrix(A)
  B <- as.matrix(B)
  ma <- dim(A)[1]
  na <- dim(A)[2]
  mb <- dim(B)[1]
  nb <- dim(B)[2]
  #check that na = mb
  if(!is.numeric(A) | !is.numeric(B))
    print("ERROR: entries in the input matrix is not numeric.")
  else if(na != mb)
    print("ERROR: the dimensions do not match.")
  else{
    #initialize result matrix to all zeros
    C = matrix(data = 0, nrow = ma, ncol = nb, byrow = TRUE)
    for(i in 1:ma){
      for(j in 1:nb){
        k <- 1
        while(k <= na){
          C[i,j] <- C[i,j] + A[i,k] * B[k,j]
          k <- k + 1
        }
      }
    }
    return(C)
  }
}

